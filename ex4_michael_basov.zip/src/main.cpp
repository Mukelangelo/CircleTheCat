#include "Controller.h"

int main()
{
	Controller().run();
}
